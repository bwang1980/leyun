#!/bin/bash
java -classpath AzulInspector.jar azulinspector.MonitorMode | tee `hostname`-AzulMonitorMode.`date +%F-%H%M`.log
